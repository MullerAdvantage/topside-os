# Dashboard Integration — Topside-OS Command Launcher

This skill is designed to live as a one-click button in the
`business-command-launcher` widget. The launcher fires fully-formed prompts into
Claude via `onclick="go('...')"`, which calls `sendPrompt(...)`. Adding this
skill means adding one button whose prompt triggers the daily log.

## Option 1 — Add a single button to the existing Operations section

Paste this `<button>` inside `<div class="grid" id="grid-ops">` in the launcher's
Widget HTML (alongside "Process job document", "New QB estimate", etc.):

```html
<button class="cmd-btn teal" onclick="go('Generate today&#39;s daily log of everything we accomplished this session — coding, analysis, and marketing reports — using the daily-log-report skill, and save it as a dated file')">
  <i class="ti ti-notebook icon" aria-hidden="true"></i>
  <span class="label">Daily log</span>
  <span class="sublabel">End-of-day recap of today's work</span>
</button>
```

## Option 2 — Add a dedicated "Reporting & Logs" section

If you'd rather give logs their own row, paste this whole block right after the
closing `</div>` of the Marketing section (`id="section-marketing"`) and before
the Research section:

```html
<div id="section-logs" class="section-wrap">
  <div class="section-label">🗒️ Reporting & logs</div>
  <div class="grid" id="grid-logs">
    <button class="cmd-btn teal" onclick="go('Generate today&#39;s daily log of everything we accomplished this session — coding, analysis, and marketing reports — using the daily-log-report skill, and save it as a dated file')">
      <i class="ti ti-notebook icon" aria-hidden="true"></i>
      <span class="label">Daily log <span class="badge badge-new">new</span></span>
      <span class="sublabel">End-of-day recap of today's work</span>
    </button>
    <button class="cmd-btn teal" onclick="go('Build a whole-day daily log — pull from all my Claude chats today, merge them, and produce one dated log using the daily-log-report skill')">
      <i class="ti ti-calendar-stats icon" aria-hidden="true"></i>
      <span class="label">Whole-day log</span>
      <span class="sublabel">Merge every chat from today into one log</span>
    </button>
    <button class="cmd-btn teal" onclick="go('Show me this week&#39;s daily logs and summarize the trend — what got done, what stayed blocked')">
      <i class="ti ti-clipboard-text icon" aria-hidden="true"></i>
      <span class="label">Weekly rollup</span>
      <span class="sublabel">Summarize the week from daily logs</span>
    </button>
  </div>
</div>
```

## Notes

- The `&#39;` in the prompts is an escaped apostrophe so "today's" doesn't break
  the inline JavaScript string. Keep it as-is.
- The `teal` class matches the Operations color. Swap to `amber` if you prefer
  it to read as marketing, or `blue`/`coral`/`purple` for other accents.
- Icons use the Tabler set already loaded in the launcher (`ti ti-...`). The
  three used here — `ti-notebook`, `ti-calendar-stats`, `ti-clipboard-text` —
  are all valid Tabler icons.
- The search box in the launcher filters by visible text automatically, so the
  new buttons become searchable ("log", "recap", "weekly") with no extra code.

## If the launcher is also stored as a standalone HTML file

You mentioned a browser-based `Topside-OS.html` launcher synced via OneDrive.
The same `<button>` markup works there verbatim — paste it into the matching
grid in that file too, so the button shows up on every device.
