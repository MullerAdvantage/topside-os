# Estimator Travel Plan Template

## Estimator Travel Plan
Origin:
Destination:
Travel Date:
Target Arrival / Departure:
Estimator:

## Recommended Route

## Best Sailing Option

## Backup Sailing Option

## Leave-Time Recommendation

## Terminal Arrival Recommendation

## Ferry Requirements / Warnings

## Travel Logistics
- Fuel:
- Food:
- Lodging:
- Parking/terminal notes:

## Risk Level
Low / Medium / High

## Verification Note

## Calendar / LEAP Scheduling Notes
- Suggested appointment window:
- Estimator availability:
- Buffer needed:
- Follow-up action:
