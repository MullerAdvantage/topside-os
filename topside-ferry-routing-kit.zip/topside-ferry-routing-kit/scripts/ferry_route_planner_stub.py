"""
Starter stub for a ferry-aware routing tool.
This is not production-complete. It gives your developer/Claude Code agent
clear structure for wiring WSDOT + Google + NWS APIs.
"""

import os
from dataclasses import dataclass
from typing import Optional

import requests


@dataclass
class TravelRequest:
    origin: str
    destination: str
    travel_date: str
    target_arrival_time: Optional[str] = None
    preferred_departure_time: Optional[str] = None
    traveler_type: str = "vehicle"


class FerryRoutePlanner:
    def __init__(self) -> None:
        self.wsdot_key = os.getenv("WSDOT_API_ACCESS_CODE")
        self.google_key = os.getenv("GOOGLE_MAPS_API_KEY")
        self.nws_user_agent = os.getenv("NWS_USER_AGENT", "TopsideRoutingTool/1.0")

        if not self.wsdot_key:
            raise RuntimeError("Missing WSDOT_API_ACCESS_CODE")
        if not self.google_key:
            raise RuntimeError("Missing GOOGLE_MAPS_API_KEY")

    def get_wsdot_routes(self):
        url = "https://www.wsdot.wa.gov/Ferries/API/Schedule/rest/routes"
        response = requests.get(url, params={"apiaccesscode": self.wsdot_key}, timeout=20)
        response.raise_for_status()
        return response.json()

    def geocode(self, address: str):
        url = "https://maps.googleapis.com/maps/api/geocode/json"
        response = requests.get(url, params={"address": address, "key": self.google_key}, timeout=20)
        response.raise_for_status()
        return response.json()

    def check_wa_weather_alerts(self):
        url = "https://api.weather.gov/alerts/active"
        headers = {"User-Agent": self.nws_user_agent}
        response = requests.get(url, params={"area": "WA"}, headers=headers, timeout=20)
        response.raise_for_status()
        return response.json()

    def plan(self, request: TravelRequest) -> dict:
        # Production version should:
        # 1. Geocode origin/destination
        # 2. Determine terminal pair
        # 3. Pull ferry schedule by terminal/date
        # 4. Pull live alerts/wait times/vessel data
        # 5. Compute Google route legs
        # 6. Return estimator-ready output
        return {
            "request": request.__dict__,
            "status": "stub_ready",
            "next_steps": [
                "Wire exact terminal matching logic.",
                "Confirm WSDOT endpoint parameters for date-specific schedule calls.",
                "Add Google Routes computeRoutes call.",
                "Add Places search for gas, food, lodging near terminals and destination.",
            ],
        }


if __name__ == "__main__":
    sample = TravelRequest(
        origin="Bellingham, WA",
        destination="Friday Harbor, WA",
        travel_date="2026-07-01",
        target_arrival_time="10:00",
    )
    planner = FerryRoutePlanner()
    print(planner.plan(sample))
