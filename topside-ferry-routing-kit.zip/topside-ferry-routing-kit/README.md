# Topside Ferry + Travel Routing Kit

This kit establishes a Claude skill and starter tool specs for ferry-aware travel planning for Topside estimators.

## What it does
- Routes ferry/travel prompts into a verified travel workflow.
- Uses WSDOT ferry schedule, terminal, vessel, fare, and travel-alert data.
- Uses Google Maps Routes/Places/Geocoding for driving, ETA, terminals, fuel, food, lodging, and route context.
- Uses NWS weather API for weather/alert context.
- Produces estimator-ready travel output: route, sailing, backup, terminal arrival time, risk level, reservations, ferry card/reservation notes, and accommodations.

## API keys needed
1. `WSDOT_API_ACCESS_CODE` — get from WSDOT Traveler API registration.
2. `GOOGLE_MAPS_API_KEY` — create in Google Cloud Console and enable Routes API, Places API, and Geocoding API.
3. `NWS_USER_AGENT` — not a key; use an identifying user-agent with contact email.

## Install into Claude skill area
Copy the file below into Claude/Claude Code skills:

`skills/ferry-travel-routing.md`

## Local setup
Copy `.env.example` to `.env` and add your keys.

```bash
cp config/.env.example .env
```

## First test prompt
```text
Plan estimator travel from Bellingham, WA to Friday Harbor, WA tomorrow morning. Include ferry options, backup sailings, terminal arrival time, reservation warning, food/gas notes, and risk level.
```

