# Claude / Claude Code Install Instructions

## Option A — Claude web skill
1. Open Claude settings.
2. Go to Skills.
3. Create a new skill named `ferry-travel-routing`.
4. Paste the contents of `skills/ferry-travel-routing.md`.
5. Save.

## Option B — Claude Code project folder
Copy this folder into your project repository:

```bash
cp -r topside-ferry-routing-kit ./topside-ferry-routing-kit
```

Then tell Claude Code:

```text
Use the ferry-travel-routing skill in ./topside-ferry-routing-kit/skills/ferry-travel-routing.md. Build the routing tool using the tool specs in ./topside-ferry-routing-kit/tools. Read API keys from .env. Do not hardcode API keys. Produce an estimator-ready route plan output.
```

## Required key locations
- WSDOT: register for a Traveler API access code.
- Google: Google Cloud Console > APIs & Services > Credentials.
- NWS: set a User-Agent value; no normal key required for api.weather.gov.
