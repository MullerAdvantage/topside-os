---
name: ferry-travel-routing
description: Ferry-aware travel planning skill for estimator routing, WSDOT ferry schedules, terminal timing, backups, travel risk, and route logistics.
---

# Ferry + Travel Routing Skill

## Mission
When the user asks for travel planning, route planning, ferry schedules, estimator travel, island jobs, terminal timing, ferry reservations, route delays, or travel feasibility, produce an estimator-ready travel plan using official and primary sources first.

## Mandatory verification rule
Use official or primary sources whenever live/current information matters. For Washington ferry information, verify through WSDOT sources before making timing claims. If live verification is unavailable, say that clearly and tell the user to confirm before departure.

## Trigger terms
Activate this skill when the prompt includes or implies any of the following:
- ferry, ferries, sailing, vessel, terminal, reservation, island job, estimator travel, route it, route planning
- Anacortes, Friday Harbor, Orcas, Lopez, Shaw, San Juan, Sidney, Coupeville, Port Townsend, Mukilteo, Clinton, Edmonds, Kingston, Bainbridge, Bremerton, Fauntleroy, Vashon, Southworth, Point Defiance, Tahlequah
- travel time, leave time, arrival time, route delay, road closure, weather delay, overnight lodging, gas, food

## Required inputs
Collect or infer:
- Origin address
- Destination address
- Travel date
- Preferred departure time or required arrival time
- Traveler type: vehicle, walk-on, commercial vehicle, or unknown
- Vehicle size if fare/reservation accuracy matters
- Estimator name if calendar matching is requested

If any critical input is missing, proceed with stated assumptions and list them.

## Data sources to use
Priority order:
1. WSDOT Ferry Schedule API or official schedule pages
2. WSDOT Ferry Alerts / VesselWatch / Terminal data
3. Google Maps Routes API for driving ETA and route geometry
4. Google Places API for gas, food, lodging, ferry terminals
5. NWS Weather API for weather alerts/conditions
6. Google Calendar / LEAP data only when connected and authorized

## Workflow
1. Validate addresses and map origin/destination.
2. Determine whether the route involves a Washington ferry.
3. Identify likely terminals and ferry route.
4. Pull schedule for the travel date.
5. Check for cancellations, route alerts, terminal wait times, and vessel issues.
6. Identify the best sailing and at least one backup sailing.
7. Calculate recommended leave time including:
   - drive time to terminal
   - terminal buffer
   - ferry crossing time
   - unloading buffer
   - drive time after ferry
8. Flag reservation requirements or strong reservation recommendations.
9. Identify gas/food/lodging only when the route duration or remote destination makes it useful.
10. Output a clean estimator-ready plan.

## Risk scoring
Use:
- Low: normal weekday route, multiple backups, no alerts, enough buffer.
- Medium: ferry-dependent route, limited backups, seasonal/peak traffic, uncertain wait times.
- High: cancellations, last sailing risk, holiday schedule, weather/road alerts, tight appointment window, or reservation uncertainty.

## Output format
Use this exact structure:

### Estimator Travel Plan
Origin:
Destination:
Travel Date:
Target Arrival / Departure:

### Recommended Route
[Driving route + ferry route + terminals]

### Best Sailing Option
[Departure terminal, departure time, arrival terminal, arrival time/crossing notes]

### Backup Sailing Option
[Backup time and feasibility]

### Leave-Time Recommendation
[When to leave origin and why]

### Terminal Arrival Recommendation
[When to arrive at terminal]

### Ferry Requirements / Warnings
[Reservation, ferry card, vehicle size, loading risk, seasonal/holiday notes]

### Travel Logistics
[Gas, food, lodging, rest stops, remote-area warnings]

### Risk Level
Low / Medium / High — [reason]

### Verification Note
[State exactly what was verified and what still needs confirmation.]
